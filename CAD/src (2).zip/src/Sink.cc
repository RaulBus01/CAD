//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "Sink.h"
#include <numeric>
Define_Module(Sink);

void Sink::initialize()
{
    lifetimeSignal = registerSignal("lifetime");
    delaySignalHighPriority = registerSignal("delayHighPriority");
    delaySignalMediumPriority = registerSignal("delayMediumPriority");
    delaySignalLowPriority = registerSignal("delayLowPriority");


}

void Sink::handleMessage(cMessage *msg)
{
    simtime_t lifetime = simTime() - msg->getCreationTime();
     emit(lifetimeSignal, lifetime);
     if(msg->arrivedOn("rxPackets"))
     {
        EV << "Received " << msg->getName() << ", lifetime: " << lifetime << "s" << endl;
        int userPriority = (int)msg->par("userPriorityType");

        switch(userPriority){
            case 3:
                delayHighPriority.push_back(lifetime);
                emit(delaySignalHighPriority, lifetime);
                EV << "Priority 3 packet delay: " << lifetime << "s" << endl;
                break;
            case 2:
                delayMediumPriority.push_back(lifetime);
                emit(delaySignalMediumPriority, lifetime);
                EV << "Priority 2 packet delay: " << lifetime << "s" << endl;
                break;
            case 1:
                delayLowPriority.push_back(lifetime);
                emit(delaySignalLowPriority, lifetime);
                EV << "Priority 1 packet delay: " << lifetime << "s" << endl;
                break;
        }
     }
      EV << "Received " << msg->getName() << ", lifetime: " << lifetime << "s" << endl;
    
      delete msg;
}

void Sink::recordDelay(simtime_t delay, int priority) {
    switch(priority) {
        case 3:
            delayHighPriority.push_back(delay);
            emit(delaySignalHighPriority, delay);
            break;
        case 2:
            delayMediumPriority.push_back(delay);
            emit(delaySignalMediumPriority, delay);
            break;
        case 1:
            delayLowPriority.push_back(delay);
            emit(delaySignalLowPriority, delay);
            break;
    }
}
void Sink::finish()
{
    // Calculate average delays
    simtime_t avgHighPriority = 0;
    simtime_t avgMediumPriority = 0;
    simtime_t avgLowPriority = 0;

    // High priority
    if (!delayHighPriority.empty()) {
        avgHighPriority = std::accumulate(delayHighPriority.begin(), 
                                        delayHighPriority.end(), 
                                        SimTime()) / delayHighPriority.size();
        recordScalar("avgHighPriority", avgHighPriority);
    }

    // Medium priority  
    if (!delayMediumPriority.empty()) {
        avgMediumPriority = std::accumulate(delayMediumPriority.begin(),
                                          delayMediumPriority.end(),
                                          SimTime()) / delayMediumPriority.size();
        recordScalar("avgMediumPriority", avgMediumPriority);
    }

    // Low priority
    if (!delayLowPriority.empty()) {
        avgLowPriority = std::accumulate(delayLowPriority.begin(),
                                       delayLowPriority.end(), 
                                       SimTime()) / delayLowPriority.size();
        recordScalar("avgLowPriority", avgLowPriority);
    }

    // Log final statistics
    EV << "\nFinal Delay Statistics:\n";
    EV << "High Priority avg delay: " << avgHighPriority << "s\n";
    EV << "Medium Priority avg delay: " << avgMediumPriority << "s\n"; 
    EV << "Low Priority avg delay: " << avgLowPriority << "s\n";
}